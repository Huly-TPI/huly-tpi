import{r as h,j as i,c as N}from"./client-CfitR-iS.js";import{b as r,d as b,S as f}from"./storage-DTJzfSKM.js";/**
 * @license lucide-react v0.395.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),w=(...e)=>e.filter((t,o,s)=>!!t&&s.indexOf(t)===o).join(" ");/**
 * @license lucide-react v0.395.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var j={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.395.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=h.forwardRef(({color:e="currentColor",size:t=24,strokeWidth:o=2,absoluteStrokeWidth:s,className:d="",children:a,iconNode:c,...k},S)=>h.createElement("svg",{ref:S,...j,width:t,height:t,stroke:e,strokeWidth:s?Number(o)*24/Number(t):o,className:w("lucide",d),...k},[...c.map(([C,A])=>h.createElement(C,A)),...Array.isArray(a)?a:[a]]));/**
 * @license lucide-react v0.395.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=(e,t)=>{const o=h.forwardRef(({className:s,...d},a)=>h.createElement(R,{ref:a,iconNode:t,className:w(`lucide-${M(e)}`,s),...d}));return o.displayName=`${e}`,o};/**
 * @license lucide-react v0.395.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=x("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]]);/**
 * @license lucide-react v0.395.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=x("Sprout",[["path",{d:"M7 20h10",key:"e6iznv"}],["path",{d:"M10 20c5.5-2.5.8-6.4 3-10",key:"161w41"}],["path",{d:"M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z",key:"9gtqwd"}],["path",{d:"M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z",key:"bkxnd2"}]]),I=({onClose:e,onRedirect:t})=>{const o=r.runtime.getURL("color-logo.webp");return i.jsx("div",{className:"huly-modal-overlay",children:i.jsxs("div",{className:"huly-modal-content",children:[i.jsx("img",{src:o,alt:"Huly",className:"huly-modal-logo"}),i.jsx("h2",{className:"huly-modal-title",children:"¿Qué tal una pausa?"}),i.jsx("p",{className:"huly-modal-text",children:"Has estado navegando un buen rato. ¿Por qué no te tomas un momento para reconectar en tu jardín?"}),i.jsxs("div",{className:"huly-modal-actions",children:[i.jsxs("button",{className:"huly-btn huly-btn-primary",onClick:t,children:[i.jsx(L,{size:18,style:{marginRight:"8px"}}),"Ir al jardín"]}),i.jsxs("button",{className:"huly-btn huly-btn-secondary",onClick:e,children:[i.jsx(T,{size:18,style:{marginRight:"8px"}}),"Recordarme más tarde"]})]})]})})},u=window.location.hostname;let m=null,y=null,n=null,l=null,g=0,v="",E="";async function H(){l=await b();const e=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"||window.location.origin.includes("huly-tpi-frontend");if(e&&(console.log("[Huly Anti-Scroll] Content script initialized on Huly page."),document.documentElement.setAttribute("data-huly-antiscroll-installed","true"),document.documentElement.setAttribute("data-huly-antiscroll-enabled",l!=null&&l.enabled?"true":"false"),document.documentElement.setAttribute("data-huly-antiscroll-consent",l!=null&&l.dataSharingConsent?"true":"false"),r.runtime.id&&document.documentElement.setAttribute("data-huly-antiscroll-id",r.runtime.id)),r.storage.onChanged.addListener(t=>{t[f.SETTINGS]&&(l={...l,...t[f.SETTINGS].newValue},e&&l&&(document.documentElement.setAttribute("data-huly-antiscroll-enabled",l.enabled?"true":"false"),document.documentElement.setAttribute("data-huly-antiscroll-consent",l.dataSharingConsent?"true":"false")))}),e){const t=sessionStorage.getItem("huly:token");t&&(console.log("[Huly Anti-Scroll] Found token on page load, sending to background."),r.runtime.sendMessage({type:"SET_TOKEN",data:{token:t}}).catch(o=>console.error("[Huly Anti-Scroll] Send token error:",o))),window.addEventListener("huly:session",o=>{var d;const s=((d=o.detail)==null?void 0:d.token)||null;console.log("[Huly Anti-Scroll] Received huly:session event, token present:",!!s),r.runtime.sendMessage({type:"SET_TOKEN",data:{token:s}}).catch(a=>console.error("[Huly Anti-Scroll] Send session token error:",a))})}z(),O()}const p=()=>!l||!l.enabled?!1:l.monitoredDomains.some(e=>u===e||u.endsWith("."+e));function z(){let e=!1;window.addEventListener("scroll",()=>{g=Date.now(),p()&&!e&&!n&&(r.runtime.sendMessage({type:"SCROLL",domain:u}),e=!0,setTimeout(()=>{e=!1},2e3))},{passive:!0});const t=()=>{m||(m=setInterval(()=>{document.visibilityState==="visible"&&Date.now()-g<2e3&&p()&&!n&&r.runtime.sendMessage({type:"TICK_ACTIVE",domain:u})},1e3))},o=()=>{m&&(clearInterval(m),m=null)};document.visibilityState==="visible"&&t(),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"?t():o()})}function O(){r.runtime.onMessage.addListener(e=>{e.type==="SHOW_PAUSE_MODAL"&&_()})}async function _(){if(n)return;const e=await b();if(!document.getElementById("huly-font-link")){const c=document.createElement("link");c.id="huly-font-link",c.rel="stylesheet",c.href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap",document.head.appendChild(c)}v=document.documentElement.style.overflow,E=document.body.style.overflow,document.documentElement.style.overflow="hidden",document.body.style.overflow="hidden",n=document.createElement("div"),n.id="huly-pause-root",n.style.position="fixed",n.style.zIndex="2147483647",n.style.top="0",n.style.left="0",n.style.width="100vw",n.style.height="100vh",n.style.pointerEvents="none",document.body.appendChild(n);const t=n.attachShadow({mode:"open"}),o=r.runtime.getURL("fonts/Nunito-Regular.ttf"),s=r.runtime.getURL("fonts/Nunito-Bold.ttf"),d=document.createElement("style");d.textContent=`
    @font-face {
      font-family: 'Nunito';
      src: url('${o}') format('truetype');
      font-weight: 400;
      font-style: normal;
    }
    @font-face {
      font-family: 'Nunito';
      src: url('${s}') format('truetype');
      font-weight: 700;
      font-style: normal;
    }
    
    .huly-modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(26, 16, 64, 0.4);
      backdrop-filter: blur(8px);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Nunito', sans-serif;
      padding: 1rem;
      box-sizing: border-box;
    }
    .huly-modal-content {
      background: #ffffff;
      padding: 2.5rem 2rem;
      border-radius: 2rem;
      box-shadow: 0 20px 50px rgba(26, 16, 64, 0.15);
      max-width: 380px;
      width: 100%;
      text-align: center;
      box-sizing: border-box;
      border: 1px solid rgba(136, 105, 172, 0.1);
    }
    .huly-modal-logo {
      height: 3.2rem;
      margin-bottom: 1.5rem;
      display: block;
      margin-left: auto;
      margin-right: auto;
      object-fit: contain;
    }
    .huly-modal-title {
      font-size: 1.5rem;
      font-weight: 800;
      margin-bottom: 1rem;
      color: #8869AC;
      margin-top: 0;
      letter-spacing: -0.02em;
    }
    .huly-modal-text {
      font-size: 1rem;
      color: #5c5c8a;
      margin-bottom: 2rem;
      line-height: 1.6;
      font-weight: 600;
    }
    .huly-modal-actions {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }
    .huly-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 9999px;
      font-weight: 500;
      line-height: 1.2;
      cursor: pointer;
      border: 1px solid transparent;
      transition: background-color 0.3s ease-in-out, border-color 0.3s ease-in-out, color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
      font-size: 0.95rem;
      width: 100%;
      padding: 0.85rem 1.35rem;
      font-family: 'Nunito', sans-serif;
      box-sizing: border-box;
    }
    .huly-btn-primary {
      background: #8869AC;
      color: white;
      border-color: transparent;
    }
    .huly-btn-primary:hover {
      box-shadow: inset 0 0 0 9999px rgba(0, 0, 0, 0.12);
    }
    .huly-btn-secondary {
      background: transparent;
      color: #8869AC;
      border-color: #8869AC;
    }
    .huly-btn-secondary:hover {
      box-shadow: inset 0 0 0 9999px rgba(0, 0, 0, 0.08);
    }
  `,t.appendChild(d);const a=document.createElement("div");a.style.pointerEvents="auto",a.style.width="100%",a.style.height="100%",t.appendChild(a),y=N.createRoot(a),r.runtime.sendMessage({type:"MODAL_SHOWN",domain:u}),y.render(i.jsx(I,{onClose:()=>{D(),r.runtime.sendMessage({type:"RESET_TIMER"})},onRedirect:()=>{r.runtime.sendMessage({type:"REDIRECT_CLICKED",domain:u}),window.location.href=e.gardenUrl}}))}function D(){y&&(y.unmount(),y=null),n&&(n.remove(),n=null),document.documentElement.style.overflow=v||"",document.body.style.overflow=E||""}H();
